const imie = document.querySelector('#imie')
const nazwisko = document.querySelector('#nazwisko')
const email = document.querySelector('#email')
const usluga = document.querySelector('#usluga')
const kopia = document.querySelector('#kopia')
const resetuj = document.querySelector('#restuj')
const przeslij = document.querySelector('#przeslij')
const wynik = document.querySelector('#wynik')



resetuj.addEventListener('click', function(){
    document.getElementById('#myForm').reset()
})

przeslij.addEventListener('click', function (){
    wynik.innerHTML = `${imie.value} ${nazwisko.value}`
})